import { ConvetirMonedaPipe } from './convetir-moneda.pipe';

describe('ConvetirMonedaPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvetirMonedaPipe();
    expect(pipe).toBeTruthy();
  });
});
