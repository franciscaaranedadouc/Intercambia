import { FormtearFechaPipe } from './formtear-fecha.pipe';

describe('FormtearFechaPipe', () => {
  it('create an instance', () => {
    const pipe = new FormtearFechaPipe();
    expect(pipe).toBeTruthy();
  });
});
